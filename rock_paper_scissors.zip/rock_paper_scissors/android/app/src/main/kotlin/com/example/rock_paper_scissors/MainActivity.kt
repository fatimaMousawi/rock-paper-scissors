package com.example.rock_paper_scissors

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
